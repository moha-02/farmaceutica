create definer = `mariadb.sys`@localhost view session_ssl_status as
select `sslver`.`THREAD_ID`        AS `thread_id`,
       `sslver`.`VARIABLE_VALUE`   AS `ssl_version`,
       `sslcip`.`VARIABLE_VALUE`   AS `ssl_cipher`,
       `sslreuse`.`VARIABLE_VALUE` AS `ssl_sessions_reused`
from ((`performance_schema`.`status_by_thread` `sslver` left join `performance_schema`.`status_by_thread` `sslcip`
       on (`sslcip`.`THREAD_ID` = `sslver`.`THREAD_ID` and
           `sslcip`.`VARIABLE_NAME` = 'Ssl_cipher')) left join `performance_schema`.`status_by_thread` `sslreuse`
      on (`sslreuse`.`THREAD_ID` = `sslver`.`THREAD_ID` and `sslreuse`.`VARIABLE_NAME` = 'Ssl_sessions_reused'))
where `sslver`.`VARIABLE_NAME` = 'Ssl_version';

-- comment on column session_ssl_status.thread_id not supported: The thread identifier of the session in which the status variable is defined.

-- comment on column session_ssl_status.ssl_version not supported: Aggregated status variable value.

-- comment on column session_ssl_status.ssl_cipher not supported: Aggregated status variable value.

-- comment on column session_ssl_status.ssl_sessions_reused not supported: Aggregated status variable value.

