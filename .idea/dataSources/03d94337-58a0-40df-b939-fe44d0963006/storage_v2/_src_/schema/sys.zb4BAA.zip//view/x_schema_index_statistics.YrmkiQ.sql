create definer = `mariadb.sys`@localhost view x$schema_index_statistics as
select `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA`    AS `table_schema`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`      AS `table_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME`       AS `index_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_FETCH`      AS `rows_selected`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_FETCH`  AS `select_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_INSERT`     AS `rows_inserted`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_INSERT` AS `insert_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_UPDATE`     AS `rows_updated`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_UPDATE` AS `update_latency`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_DELETE`     AS `rows_deleted`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_INSERT` AS `delete_latency`
from `performance_schema`.`table_io_waits_summary_by_index_usage`
where `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` is not null
order by `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_WAIT` desc;

-- comment on column x$schema_index_statistics.table_schema not supported: Schema name.

-- comment on column x$schema_index_statistics.table_name not supported: Table name.

-- comment on column x$schema_index_statistics.index_name not supported: Index name, or PRIMARY for the primary index, NULL for no index (inserts are counted in this case).

-- comment on column x$schema_index_statistics.rows_selected not supported: Number of all fetch operations.

-- comment on column x$schema_index_statistics.select_latency not supported: Total wait time of all fetch operations that are timed.

-- comment on column x$schema_index_statistics.rows_inserted not supported: Number of all insert operations.

-- comment on column x$schema_index_statistics.insert_latency not supported: Total wait time of all insert operations that are timed.

-- comment on column x$schema_index_statistics.rows_updated not supported: Number of all update operations.

-- comment on column x$schema_index_statistics.update_latency not supported: Total wait time of all update operations that are timed.

-- comment on column x$schema_index_statistics.rows_deleted not supported: Number of all delete operations.

-- comment on column x$schema_index_statistics.delete_latency not supported: Total wait time of all insert operations that are timed.

