create definer = `mariadb.sys`@localhost view x$schema_tables_with_full_table_scans as
select `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA`  AS `object_schema`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`    AS `object_name`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_READ`     AS `rows_full_scanned`,
       `performance_schema`.`table_io_waits_summary_by_index_usage`.`SUM_TIMER_WAIT` AS `latency`
from `performance_schema`.`table_io_waits_summary_by_index_usage`
where `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` is null
  and `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_READ` > 0
order by `performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_READ` desc;

-- comment on column x$schema_tables_with_full_table_scans.object_schema not supported: Schema name.

-- comment on column x$schema_tables_with_full_table_scans.object_name not supported: Table name.

-- comment on column x$schema_tables_with_full_table_scans.rows_full_scanned not supported: Number of all read operations, and the sum of the equivalent x_FETCH columns.

-- comment on column x$schema_tables_with_full_table_scans.latency not supported: Total wait time of the summarized events that are timed.

